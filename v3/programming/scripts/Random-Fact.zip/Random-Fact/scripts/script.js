var facts = [
    'This is a Fact!',
    'Styling this tiny snippet was not easy',
    'HTML, CSS and JS are things'
]

function newFact() {
    var factNumber = Math.floor(Math.random() * (facts.length));
    document.getElementById('factElement').innerHTML = facts[factNumber];
}